import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from scipy.stats import linregress, pearsonr

st.set_page_config(
    page_title="지역별 의료 인프라와 건강검진 수검률",
    page_icon="🏥",
    layout="wide"
)

st.title("🏥 우리나라 지역별 의료 인프라 차이와 건강검진 수검률의 차이")
st.caption("지역별 의료기관 수와 건강검진 수검률의 관계를 산점도와 회귀분석으로 살펴봅니다.")

st.markdown("""
이 앱은 건강검진 대상 인원·수검 인원, 의료기관 수, 주민등록인구 자료를 결합해
지역별 건강검진 수검률과 의료 인프라 수준의 관계를 분석합니다.
""")

REGION_MAP = {
    "서울": "서울특별시", "서울특별시": "서울특별시",
    "부산": "부산광역시", "부산광역시": "부산광역시",
    "대구": "대구광역시", "대구광역시": "대구광역시",
    "인천": "인천광역시", "인천광역시": "인천광역시",
    "광주": "광주광역시", "광주광역시": "광주광역시",
    "대전": "대전광역시", "대전광역시": "대전광역시",
    "울산": "울산광역시", "울산광역시": "울산광역시",
    "세종": "세종특별자치시", "세종특별자치시": "세종특별자치시",
    "경기": "경기도", "경기도": "경기도",
    "강원": "강원특별자치도", "강원특별자치도": "강원특별자치도",
    "충북": "충청북도", "충청북도": "충청북도",
    "충남": "충청남도", "충청남도": "충청남도",
    "전북": "전북특별자치도", "전라북도": "전북특별자치도",
    "전북특별자치도": "전북특별자치도",
    "전남": "전라남도", "전라남도": "전라남도",
    "경북": "경상북도", "경상북도": "경상북도",
    "경남": "경상남도", "경상남도": "경상남도",
    "제주": "제주특별자치도", "제주특별자치도": "제주특별자치도",
}

def normalize_region(value):
    """한글 시도명 또는 '서울 Seoul' 같은 의료기관 파일의 표기를 표준화."""
    if pd.isna(value):
        return None
    value = str(value).strip()
    if value in REGION_MAP:
        return REGION_MAP[value]
    first = value.split()[0]
    return REGION_MAP.get(first, REGION_MAP.get(value, value))

def read_csv_safely(uploaded_file):
    """한글 CSV의 UTF-8/CP949 인코딩 차이를 처리."""
    raw = uploaded_file.getvalue()
    for encoding in ("utf-8-sig", "cp949", "euc-kr", "utf-8"):
        try:
            from io import BytesIO
            return pd.read_csv(BytesIO(raw), encoding=encoding)
        except UnicodeDecodeError:
            continue
    raise ValueError("CSV 인코딩을 읽을 수 없습니다. UTF-8 또는 CP949로 저장해 주세요.")

def to_number(series):
    return pd.to_numeric(
        series.astype(str).str.replace(",", "", regex=False).str.strip(),
        errors="coerce"
    )

def find_column(columns, candidates):
    for candidate in candidates:
        if candidate in columns:
            return candidate
    return None

with st.sidebar:
    st.header("📂 자료 업로드")
    health_file = st.file_uploader(
        "① 건강검진 대상·수검 인원 CSV",
        type=["csv"],
        key="health"
    )
    hospital_file = st.file_uploader(
        "② 지역별 의료기관 수 CSV",
        type=["csv"],
        key="hospital"
    )
    population_file = st.file_uploader(
        "③ 지역별 주민등록인구 CSV",
        type=["csv"],
        key="population"
    )
    st.divider()
    st.caption("세 파일을 모두 업로드하면 분석이 시작됩니다.")

if not all([health_file, hospital_file, population_file]):
    st.info("왼쪽 메뉴에서 건강검진·의료기관·주민등록인구 CSV 파일 3개를 모두 업로드해 주세요.")
    st.markdown("""
    **필요한 자료 형식**
    - 건강검진: `시도`, `대상인원`, `수검인원`
    - 의료기관: `연도`, `시도`, `병의원_종합병원`, `병의원_요양병원`, `병의원_일반병원`, `병의원_의원`
    - 인구: `행정구역(시군구)별`, `연령별`, `2024.12`와 같이 인구수가 들어 있는 열
    """)
    st.stop()

try:
    health_raw = read_csv_safely(health_file)
    hospital_raw = read_csv_safely(hospital_file)
    population_raw = read_csv_safely(population_file)

    # -----------------------------
    # 1. 건강검진 데이터 정리
    # -----------------------------
    h_region = find_column(health_raw.columns, ["시도", "지역", "행정구역"])
    h_target = find_column(health_raw.columns, ["대상인원", "검진대상인원", "대상자수"])
    h_exam = find_column(health_raw.columns, ["수검인원", "검진인원", "수검자수"])

    if not all([h_region, h_target, h_exam]):
        st.error("건강검진 CSV에서 시도·대상인원·수검인원 열을 찾지 못했습니다.")
        st.write("현재 열 이름:", health_raw.columns.tolist())
        st.stop()

    health = health_raw[[h_region, h_target, h_exam]].copy()
    health.columns = ["지역", "대상인원", "수검인원"]
    health["지역"] = health["지역"].apply(normalize_region)
    health["대상인원"] = to_number(health["대상인원"])
    health["수검인원"] = to_number(health["수검인원"])
    health = health.dropna(subset=["지역", "대상인원", "수검인원"])
    health = health.groupby("지역", as_index=False)[["대상인원", "수검인원"]].sum()
    health["수검률(%)"] = health["수검인원"] / health["대상인원"] * 100

    # -----------------------------
    # 2. 의료기관 데이터 정리
    # -----------------------------
    required_hospital = [
        "연도", "시도", "병의원_종합병원",
        "병의원_요양병원", "병의원_일반병원", "병의원_의원"
    ]
    missing_hospital = [c for c in required_hospital if c not in hospital_raw.columns]
    if missing_hospital:
        st.error(f"의료기관 CSV에 필요한 열이 없습니다: {missing_hospital}")
        st.write("현재 열 이름:", hospital_raw.columns.tolist())
        st.stop()

    hospital = hospital_raw[required_hospital].copy()
    hospital["연도"] = to_number(hospital["연도"])
    hospital["지역"] = hospital["시도"].apply(normalize_region)
    hospital_types = [
        "병의원_종합병원", "병의원_요양병원",
        "병의원_일반병원", "병의원_의원"
    ]
    for col in hospital_types:
        hospital[col] = to_number(hospital[col]).fillna(0)
    hospital["의료기관 수"] = hospital[hospital_types].sum(axis=1)

    available_years = sorted(hospital["연도"].dropna().astype(int).unique().tolist())
    if not available_years:
        st.error("의료기관 자료에서 연도를 확인할 수 없습니다.")
        st.stop()

    default_year = max(available_years)
    selected_year = st.sidebar.selectbox(
        "의료기관 자료 연도 선택",
        available_years,
        index=available_years.index(default_year)
    )

    hospital_year = hospital[hospital["연도"] == selected_year].copy()
    hospital_year = hospital_year.groupby("지역", as_index=False)["의료기관 수"].sum()

    # -----------------------------
    # 3. 주민등록인구 데이터 정리
    # -----------------------------
    p_region = find_column(population_raw.columns, ["행정구역(시군구)별", "행정구역", "지역"])
    p_age = find_column(population_raw.columns, ["연령별", "연령"])
    if not p_region:
        st.error("인구 CSV에서 행정구역 열을 찾지 못했습니다.")
        st.write("현재 열 이름:", population_raw.columns.tolist())
        st.stop()

    population_columns = [
        c for c in population_raw.columns
        if c not in [p_region, p_age] and not str(c).startswith("Unnamed")
    ]
    if not population_columns:
        st.error("인구수가 들어 있는 열을 찾지 못했습니다.")
        st.stop()

    # 여러 시점이 있다면 가장 오른쪽의 인구 열을 기본값으로 사용
    default_pop_col = population_columns[-1]
    pop_col = st.sidebar.selectbox(
        "주민등록인구 기준 열 선택",
        population_columns,
        index=population_columns.index(default_pop_col)
    )

    population = population_raw.copy()
    population["지역"] = population[p_region].apply(normalize_region)
    population[pop_col] = to_number(population[pop_col])

    # 연령별 자료 중 '계' 행만 사용하여 전체 인구를 가져옴
    if p_age:
        population = population[
            population[p_age].astype(str).str.strip().isin(["계", "총계", "전체"])
        ].copy()

    population = population[
        population["지역"].notna() &
        (population["지역"] != "전국")
    ]
    population = population.groupby("지역", as_index=False)[pop_col].sum()
    population = population.rename(columns={pop_col: "인구 수"})

    # -----------------------------
    # 4. 세 자료 결합
    # -----------------------------
    data = health.merge(hospital_year, on="지역", how="inner")
    data = data.merge(population, on="지역", how="inner")
    data = data.dropna(subset=["수검률(%)", "의료기관 수", "인구 수"])
    data = data[data["인구 수"] > 0].copy()

    if data.empty:
        st.error("세 자료에서 일치하는 지역을 찾지 못했습니다. 지역명 표기를 확인해 주세요.")
        st.stop()

    data["인구 1만 명당 의료기관 수"] = data["의료기관 수"] / data["인구 수"] * 10000
    data["의료기관 1곳당 인구 수"] = data["인구 수"] / data["의료기관 수"].replace(0, pd.NA)

    # -----------------------------
    # 5. 자료 결합 상태 및 주의사항
    # -----------------------------
    st.subheader("📌 분석 자료 확인")
    c1, c2, c3 = st.columns(3)
    c1.metric("분석 지역 수", f"{len(data)}개")
    c2.metric("의료기관 자료 연도", f"{selected_year}년")
    c3.metric("건강검진 자료 지역 수", f"{len(health)}개")

    missing_h = sorted(set(health["지역"]) - set(hospital_year["지역"]))
    missing_p = sorted(set(health["지역"]) - set(population["지역"]))
    if missing_h or missing_p:
        with st.expander("자료 결합에서 제외된 지역 확인"):
            if missing_h:
                st.write("의료기관 자료와 연결되지 않은 지역:", ", ".join(missing_h))
            if missing_p:
                st.write("인구 자료와 연결되지 않은 지역:", ", ".join(missing_p))

    st.warning(
        "건강검진 CSV에는 조사 연도 열이 없습니다. 의료기관 자료 연도와 "
        "건강검진 자료의 기준 연도가 일치하는지 원자료에서 확인해야 합니다. "
        "인구 자료는 선택한 열의 기준 시점으로 표시됩니다."
    )

    # -----------------------------
    # 6. 사이드바 분석 변수 선택
    # -----------------------------
    st.sidebar.divider()
    x_choice = st.sidebar.radio(
        "산점도 X축(의료 인프라 지표)",
        ["인구 1만 명당 의료기관 수", "의료기관 수"]
    )

    # -----------------------------
    # 7. 핵심 지표
    # -----------------------------
    st.header("1. 지역별 건강검진 현황")
    total_target = data["대상인원"].sum()
    total_exam = data["수검인원"].sum()
    weighted_rate = total_exam / total_target * 100 if total_target else 0

    m1, m2, m3 = st.columns(3)
    m1.metric("분석 지역", f"{len(data)}개")
    m2.metric("검진 대상 인원 합계", f"{total_target:,.0f}명")
    m3.metric("전체 가중 수검률", f"{weighted_rate:.2f}%")

    st.dataframe(
        data[[
            "지역", "대상인원", "수검인원", "수검률(%)",
            "의료기관 수", "인구 수", "인구 1만 명당 의료기관 수"
        ]].sort_values("수검률(%)", ascending=False).style.format({
            "대상인원": "{:,.0f}",
            "수검인원": "{:,.0f}",
            "수검률(%)": "{:.2f}",
            "의료기관 수": "{:,.0f}",
            "인구 수": "{:,.0f}",
            "인구 1만 명당 의료기관 수": "{:.2f}"
        }),
        use_container_width=True
    )

    # -----------------------------
    # 8. 지역별 수검률 막대그래프
    # -----------------------------
    st.header("2. 지역별 건강검진 수검률 비교")
    bar_data = data.sort_values("수검률(%)", ascending=False)
    fig_bar = px.bar(
        bar_data,
        x="지역",
        y="수검률(%)",
        text=bar_data["수검률(%)"].map(lambda x: f"{x:.1f}%"),
        title="지역별 건강검진 수검률",
        labels={"지역": "지역", "수검률(%)": "수검률(%)"}
    )
    fig_bar.update_layout(xaxis_tickangle=-45)
    st.plotly_chart(fig_bar, use_container_width=True)

    # -----------------------------
    # 9. 산점도와 단순 선형 회귀
    # -----------------------------
    st.header("3. 의료 인프라와 건강검진 수검률의 관계")
    st.write(
        f"X축은 **{x_choice}**, Y축은 **건강검진 수검률(%)**입니다. "
        "점 하나는 하나의 시도를 나타냅니다."
    )

    x = data[x_choice].astype(float)
    y = data["수검률(%)"].astype(float)

    if len(data) >= 3 and x.nunique() >= 2:
        result = linregress(x, y)
        slope = result.slope
        intercept = result.intercept
        r_value = result.rvalue
        r_squared = result.rvalue ** 2
        p_value = result.pvalue

        plot_data = data.copy()
        plot_data["회귀 예측 수검률"] = intercept + slope * plot_data[x_choice]

        fig_scatter = px.scatter(
            plot_data,
            x=x_choice,
            y="수검률(%)",
            text="지역",
            hover_data={
                "대상인원": ":,",
                "수검인원": ":,",
                "의료기관 수": ":,",
                "인구 수": ":,",
                "인구 1만 명당 의료기관 수": ":.2f"
            },
            title=f"{x_choice}와 건강검진 수검률의 산점도 및 회귀직선"
        )
        line_data = plot_data.sort_values(x_choice)
        fig_scatter.add_trace(go.Scatter(
            x=line_data[x_choice],
            y=line_data["회귀 예측 수검률"],
            mode="lines",
            name="선형 회귀직선"
        ))
        fig_scatter.update_traces(selector=dict(mode="markers+text"), textposition="top center")
        fig_scatter.update_layout(
            xaxis_title=x_choice,
            yaxis_title="건강검진 수검률(%)"
        )
        st.plotly_chart(fig_scatter, use_container_width=True)

        a, b, c, d = st.columns(4)
        a.metric("상관계수 r", f"{r_value:.3f}")
        b.metric("결정계수 R²", f"{r_squared:.3f}")
        c.metric("회귀 기울기", f"{slope:.4f}")
        d.metric("p-value", f"{p_value:.4f}")

        st.markdown("**회귀식**")
        st.latex(
            rf"\\hat{{Y}} = {intercept:.4f} + ({slope:.4f})X"
        )

        if slope > 0:
            direction = "양(+)의 관계"
        elif slope < 0:
            direction = "음(-)의 관계"
        else:
            direction = "기울기가 0인 관계"

        st.write(f"- 회귀 기울기 해석: 의료 인프라 지표와 수검률 사이에 **{direction}**이 관찰됩니다.")
        st.write(f"- 결정계수 해석: 이 단순 선형 모형은 지역별 수검률 변동의 약 **{r_squared * 100:.1f}%**를 설명합니다.")
        if p_value < 0.05:
            st.write("- p-value가 0.05보다 작아, 통상적인 5% 유의수준에서 선형 관계가 통계적으로 유의합니다.")
        else:
            st.write("- p-value가 0.05 이상이므로, 통상적인 5% 유의수준에서 선형 관계가 통계적으로 유의하다고 보기 어렵습니다.")
    else:
        st.warning("회귀분석을 하려면 분석 지역이 3개 이상이고 X축 값이 서로 다른 지역이 2개 이상이어야 합니다.")

    # -----------------------------
    # 10. 상관관계 분석
    # -----------------------------
    st.header("4. 주요 변수 간 상관관계")
    corr_cols = [
        "대상인원", "수검인원", "수검률(%)",
        "의료기관 수", "인구 수", "인구 1만 명당 의료기관 수"
    ]
    corr = data[corr_cols].corr(numeric_only=True)
    fig_corr = px.imshow(
        corr,
        text_auto=".2f",
        aspect="auto",
        color_continuous_scale="RdBu_r",
        zmin=-1,
        zmax=1,
        title="지역별 주요 변수 상관관계 히트맵"
    )
    st.plotly_chart(fig_corr, use_container_width=True)

    # -----------------------------
    # 11. 다운로드
    # -----------------------------
    st.header("5. 분석 결과 다운로드")
    download_df = data.copy()
    csv = download_df.to_csv(index=False, encoding="utf-8-sig")
    st.download_button(
        "📥 지역별 통합 분석 데이터 CSV 다운로드",
        data=csv,
        file_name="지역별_의료인프라_건강검진_분석.csv",
        mime="text/csv"
    )

    st.divider()
    st.subheader("📝 탐구 결론 작성 시 참고")
    st.markdown("""
    1. 산점도에서 점들이 회귀직선 주변에 모여 있는지 확인합니다.
    2. 회귀 기울기가 양수인지 음수인지 확인합니다.
    3. R²로 의료 인프라 지표가 수검률 차이를 얼마나 설명하는지 살펴봅니다.
    4. p-value를 확인해 관찰된 선형 관계의 통계적 유의성을 검토합니다.
    5. 이 분석은 지역 단위의 관찰자료이므로, 병원이 많아서 수검률이 높아졌다는 인과관계까지 증명하지는 않습니다.
    """)

except Exception as e:
    st.error("자료를 처리하는 중 오류가 발생했습니다.")
    st.exception(e)
